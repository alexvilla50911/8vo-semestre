﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        // Ruta de donde esta el archivo 491 html
        string rutaArchivo = "491.html";

        // Aqui se lee el contenido del archivo.
        string contenidoHTML = File.ReadAllText(rutaArchivo);

        //cronómetro para medir el tiempo total
        Stopwatch tiempoTotal = Stopwatch.StartNew();

        // Aqui se eliminan las etiquetas de HTML
        string contenidoSinHTML = EliminarEtiquetasHTML(contenidoHTML);

        // Aqui se extraen las palabras ya sin etiquetas y sin numeros tambien :)
        List<string> palabras = ObtenerPalabrasSinNumeros(contenidoSinHTML);

        // aqui se ordenan las palabras en orden alfabetico.
        palabras.Sort();

    

        // cronómetro para medir el tiempo de impresión de todas las palabras
        Stopwatch tiempoImpresion = Stopwatch.StartNew();

        // Aqui se imprimen las palabras en orden alfabético sin números
        Console.WriteLine("Palabras en orden alfabético:");
        foreach (var palabra in palabras)
        {
            Console.WriteLine(palabra);
        }

        // aqui se detiene el cronómetro de impresión y muestra el tiempo
        tiempoImpresion.Stop();
        Console.WriteLine($"Tiempo de impresión de las palabras: {tiempoImpresion.ElapsedMilliseconds} ms");

         // aqui se detiene el cronómetro y muestra el tiempo total que tardo el programa
        tiempoTotal.Stop();
        Console.WriteLine($"Tiempo total de ejecución del programa: {tiempoTotal.ElapsedMilliseconds} ms");

        Console.WriteLine("Actividad 3 Hecha por equipo 3: ");
    }

    static string EliminarEtiquetasHTML(string html)
    {
        //eliminar las etiquetas HTML
        string patronHTML = @"<[^>]+>|&nbsp;";
        return Regex.Replace(html, patronHTML, string.Empty);
    }

    static List<string> ObtenerPalabrasSinNumeros(string texto)
    {
        //aqui se extraen las palabras sin números
        Regex regex = new Regex(@"\b(?:[^\W\d_]|-)+\b");
        MatchCollection coincidencias = regex.Matches(texto);

        // aqui se hace una lista con las palabras
        List<string> palabras = new List<string>();

        // y finalmente se agregan las palabras a la lista
        foreach (Match coincidencia in coincidencias)
        {
            palabras.Add(coincidencia.Value);
        }

        //Y pues, imprime las palabras.
        return palabras;

    }
}
