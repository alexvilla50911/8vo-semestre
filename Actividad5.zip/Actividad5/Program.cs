﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        Stopwatch totalTimeStopwatch = Stopwatch.StartNew();

        // Rutas de los archivos HTML
        string[] filePaths = { "simple.html", "medium.html", "hard.html", "049.html" };

        // Leer archivos HTML y almacenar contenido
        List<string> contents = new List<string>();
        foreach (var filePath in filePaths)
        {
            if (File.Exists(filePath))
            {
                string content = File.ReadAllText(filePath);
                contents.Add(content);
            }
            else
            {
                Console.WriteLine($"El archivo {filePath} no existe.");
            }
        }

        // Obtener palabras y su frecuencia
        Stopwatch wordFrequencyStopwatch = Stopwatch.StartNew();
        var wordFrequency = GetWordFrequency(contents);
        wordFrequencyStopwatch.Stop();

        // Filtrar palabras no deseadas
        var filteredWords = wordFrequency.Where(pair => IsWordValid(pair.Key)).OrderBy(pair => pair.Key);

        // Imprimir palabras y su frecuencia
        Stopwatch printWordsStopwatch = Stopwatch.StartNew();
        Console.WriteLine("Palabras y su frecuencia (en orden alfabético):");
        foreach (var pair in filteredWords)
        {
            Console.WriteLine($"{pair.Key}: {pair.Value} veces");
        }
        printWordsStopwatch.Stop();

        totalTimeStopwatch.Stop();

        // Mostrar tiempos
        Console.WriteLine($"\nTiempo en obtener palabras y su frecuencia: {wordFrequencyStopwatch.ElapsedMilliseconds} ms");
        Console.WriteLine($"Tiempo en imprimir todas las palabras y contarlas: {printWordsStopwatch.ElapsedMilliseconds} ms");
        Console.WriteLine($"Tiempo total en ejecutar el programa: {totalTimeStopwatch.ElapsedMilliseconds} ms");
    }

    static Dictionary<string, int> GetWordFrequency(List<string> contents)
    {
        // Obtener todas las palabras de los archivos
        var allWords = contents
            .SelectMany(content => Regex.Split(content, @"\W+")) // Dividir por caracteres no alfanuméricos
            .Where(word => !string.IsNullOrWhiteSpace(word)); // Excluye palabras vacías

        // Contar la frecuencia de cada palabra
        var wordFrequency = new Dictionary<string, int>();
        foreach (var word in allWords)
        {
            if (wordFrequency.ContainsKey(word))
                wordFrequency[word]++;
            else
                wordFrequency[word] = 1;
        }

        return wordFrequency;
    }

    static bool IsWordValid(string word)
    {
        // Filtro para excluir palabras que contienen números o etiquetas HTML
        return !Regex.IsMatch(word, @"^\d+$") && !Regex.IsMatch(word, @"<[^>]+>");
    }
}
